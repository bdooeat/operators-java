/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author bdooeat
 */
public class Operators {
    
    public static void main(String[] args) {
        int int1, int2, intResult;
        
        System.out.println("Kategori operators:");
        
        System.out.println("Enter first integer number:");
        Scanner s = new Scanner(System.in);
        int1 = s.nextInt();
        int2 = s.nextInt();
        
        intResult = int1 + int2;
        
        ////// output //////
        System.out.println("\nResult: \n" +intResult);
    }
    
}
