import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author bdooeat
 */
public class NewJFrame extends javax.swing.JFrame {
    
    int x;
    int y;
    int result;
    
    public NewJFrame() {
        initComponents();
        
        textX.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
//                String strItemSederhana = itemAssignSederhana.getActionCommand();
                labelResultX.setText("X: " +textX.getText());
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                labelResultX.setText("X: " +textX.getText());
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                labelResultX.setText("X: " +textX.getText());
            }
        });
        
        textY.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                labelResultY.setText("Y: " +textY.getText());
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                labelResultY.setText("Y: " +textY.getText());
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                labelResultY.setText("Y: " +textY.getText());
            }
        });
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        labelX = new javax.swing.JLabel();
        textX = new javax.swing.JTextField();
        textY = new javax.swing.JTextField();
        labelY = new javax.swing.JLabel();
        resetX = new javax.swing.JButton();
        resetY = new javax.swing.JButton();
        labelResultY = new javax.swing.JLabel();
        labelResultX = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        textAssignmentPlus = new javax.swing.JTextField();
        textAssignmentMin = new javax.swing.JTextField();
        textAssignmentMultiply = new javax.swing.JTextField();
        textAssignmentDivide = new javax.swing.JTextField();
        textAssignmentModulus = new javax.swing.JTextField();
        textAssignmentAND = new javax.swing.JTextField();
        textAssignmentOR = new javax.swing.JTextField();
        textAssignmentXOR = new javax.swing.JTextField();
        calculate = new javax.swing.JButton();
        textBitwiseAND = new javax.swing.JTextField();
        textBitwiseOR = new javax.swing.JTextField();
        textBitwiseXOR = new javax.swing.JTextField();
        textRelationalEqualLess = new javax.swing.JTextField();
        textRelationalMore = new javax.swing.JTextField();
        textRelationalLess = new javax.swing.JTextField();
        textRelationalNotEqual = new javax.swing.JTextField();
        textRelationalEqual = new javax.swing.JTextField();
        textRelationalEqualMore = new javax.swing.JTextField();
        textBooleanANDEvaluation = new javax.swing.JTextField();
        textBooleanOREvaluation = new javax.swing.JTextField();
        textBooleanXOREvaluation = new javax.swing.JTextField();
        textBooleanANDLogical = new javax.swing.JTextField();
        textBooleanORLogical = new javax.swing.JTextField();
        textBooleanNegation = new javax.swing.JTextField();
        textBooleanEqual = new javax.swing.JTextField();
        textBooleanNotEqual = new javax.swing.JTextField();
        jToggleButton1 = new javax.swing.JToggleButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        itemClose = new javax.swing.JMenuItem();
        jMenuAssignment = new javax.swing.JMenu();
        itemAssignSederhana = new javax.swing.JMenuItem();
        itemAssignTambah = new javax.swing.JMenuItem();
        itemAssignKurang = new javax.swing.JMenuItem();
        itemAssignBagi = new javax.swing.JMenuItem();
        itemAssignModulus = new javax.swing.JMenuItem();
        itemAssignAND = new javax.swing.JMenuItem();
        itemAssignOR = new javax.swing.JMenuItem();
        itemAssignXOR = new javax.swing.JMenuItem();
        jMenuBitwise = new javax.swing.JMenu();
        itemBitwiseAND = new javax.swing.JMenuItem();
        itemBitwiseOR = new javax.swing.JMenuItem();
        itemBitwiseXOR = new javax.swing.JMenuItem();
        jMenuRelational = new javax.swing.JMenu();
        itemRelationalLess = new javax.swing.JMenuItem();
        itemRelationalMore = new javax.swing.JMenuItem();
        itemRelationalLessEqual = new javax.swing.JMenuItem();
        itemRelationalMoreEqual = new javax.swing.JMenuItem();
        itemRelationalEqual = new javax.swing.JMenuItem();
        itemRelationalNotEqual = new javax.swing.JMenuItem();
        jMenuBoolean = new javax.swing.JMenu();
        itemBooleanANDeval = new javax.swing.JMenuItem();
        itemBooleanOREval = new javax.swing.JMenuItem();
        itemBooleanXOReval = new javax.swing.JMenuItem();
        itemBooleanANDlogic = new javax.swing.JMenuItem();
        itemBooleanORlogic = new javax.swing.JMenuItem();
        itemBooleanNegation = new javax.swing.JMenuItem();
        itemBooleanEqual = new javax.swing.JMenuItem();
        itemBooleanNotEqual = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelX.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelX.setForeground(new java.awt.Color(255, 0, 51));
        labelX.setText("X");
        labelX.setToolTipText("Variabel X");

        textX.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        textY.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        labelY.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelY.setForeground(new java.awt.Color(0, 153, 255));
        labelY.setText("Y");
        labelY.setToolTipText("Variabel X");

        resetX.setText("Reset X");
        resetX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetXActionPerformed(evt);
            }
        });

        resetY.setText("Reset Y");
        resetY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetYActionPerformed(evt);
            }
        });

        labelResultY.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelResultY.setForeground(new java.awt.Color(0, 153, 255));

        labelResultX.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelResultX.setForeground(new java.awt.Color(255, 0, 51));

        textArea.setColumns(20);
        textArea.setFont(new java.awt.Font("Droid Sans Mono", 0, 18)); // NOI18N
        textArea.setForeground(new java.awt.Color(0, 153, 102));
        textArea.setRows(5);
        jScrollPane1.setViewportView(textArea);

        jLabel1.setText("ASSIGNMENT");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("+=");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("-=");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setText("*=");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("/=");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText("%=");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText("&=");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText("|=");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setText("^=");

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel20.setText("^ XOR");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("|| OR");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("& AND");

        jLabel6.setText("BITWISE");

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel23.setText("!=");

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel24.setText("==");

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel25.setText(">=");

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel26.setText("<=");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText(">");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("<");

        jLabel27.setText("RELATIONAL");

        jLabel28.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel28.setText("!=");

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel29.setText("==");

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel30.setText("!");

        jLabel31.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel31.setText("||");

        jLabel32.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel32.setText("&&");

        jLabel33.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel33.setText("^");

        jLabel34.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel34.setText("|");

        jLabel35.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel35.setText("&");

        jLabel36.setText("BOOLEAN");

        jLabel38.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        textAssignmentPlus.setEditable(false);
        textAssignmentPlus.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentPlus.setForeground(new java.awt.Color(0, 153, 51));

        textAssignmentMin.setEditable(false);
        textAssignmentMin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentMin.setForeground(new java.awt.Color(0, 153, 51));

        textAssignmentMultiply.setEditable(false);
        textAssignmentMultiply.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentMultiply.setForeground(new java.awt.Color(0, 153, 51));

        textAssignmentDivide.setEditable(false);
        textAssignmentDivide.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentDivide.setForeground(new java.awt.Color(0, 153, 51));

        textAssignmentModulus.setEditable(false);
        textAssignmentModulus.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentModulus.setForeground(new java.awt.Color(0, 153, 51));

        textAssignmentAND.setEditable(false);
        textAssignmentAND.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentAND.setForeground(new java.awt.Color(0, 153, 51));

        textAssignmentOR.setEditable(false);
        textAssignmentOR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentOR.setForeground(new java.awt.Color(0, 153, 51));

        textAssignmentXOR.setEditable(false);
        textAssignmentXOR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textAssignmentXOR.setForeground(new java.awt.Color(0, 153, 51));

        calculate.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        calculate.setForeground(new java.awt.Color(255, 255, 102));
        calculate.setText("CALCULATE");
        calculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateActionPerformed(evt);
            }
        });

        textBitwiseAND.setEditable(false);
        textBitwiseAND.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBitwiseAND.setForeground(new java.awt.Color(0, 153, 51));

        textBitwiseOR.setEditable(false);
        textBitwiseOR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBitwiseOR.setForeground(new java.awt.Color(0, 153, 51));

        textBitwiseXOR.setEditable(false);
        textBitwiseXOR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBitwiseXOR.setForeground(new java.awt.Color(0, 153, 51));

        textRelationalEqualLess.setEditable(false);
        textRelationalEqualLess.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textRelationalEqualLess.setForeground(new java.awt.Color(0, 153, 51));

        textRelationalMore.setEditable(false);
        textRelationalMore.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textRelationalMore.setForeground(new java.awt.Color(0, 153, 51));

        textRelationalLess.setEditable(false);
        textRelationalLess.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textRelationalLess.setForeground(new java.awt.Color(0, 153, 51));

        textRelationalNotEqual.setEditable(false);
        textRelationalNotEqual.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textRelationalNotEqual.setForeground(new java.awt.Color(0, 153, 51));

        textRelationalEqual.setEditable(false);
        textRelationalEqual.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textRelationalEqual.setForeground(new java.awt.Color(0, 153, 51));

        textRelationalEqualMore.setEditable(false);
        textRelationalEqualMore.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textRelationalEqualMore.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanANDEvaluation.setEditable(false);
        textBooleanANDEvaluation.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanANDEvaluation.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanOREvaluation.setEditable(false);
        textBooleanOREvaluation.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanOREvaluation.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanXOREvaluation.setEditable(false);
        textBooleanXOREvaluation.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanXOREvaluation.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanANDLogical.setEditable(false);
        textBooleanANDLogical.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanANDLogical.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanORLogical.setEditable(false);
        textBooleanORLogical.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanORLogical.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanNegation.setEditable(false);
        textBooleanNegation.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanNegation.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanEqual.setEditable(false);
        textBooleanEqual.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanEqual.setForeground(new java.awt.Color(0, 153, 51));

        textBooleanNotEqual.setEditable(false);
        textBooleanNotEqual.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        textBooleanNotEqual.setForeground(new java.awt.Color(0, 153, 51));

        jToggleButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jToggleButton1.setText("INVERT X WITH Y");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(resetX, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(resetY, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelX)
                            .addComponent(labelY, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(textY, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(labelResultY, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(textX, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(labelResultX, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(calculate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGap(140, 140, 140)
                                            .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(textAssignmentPlus, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(textAssignmentMin, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(textAssignmentMultiply, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel5)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(textBitwiseAND, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(textBitwiseOR, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(textBitwiseXOR, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(18, 18, 18)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(textAssignmentDivide, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textAssignmentModulus, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textAssignmentAND, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel26, javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel24, javax.swing.GroupLayout.Alignment.TRAILING)))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGap(14, 14, 14)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(textRelationalLess, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textRelationalMore, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textRelationalEqualLess, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textRelationalEqualMore, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textRelationalEqual, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textRelationalNotEqual, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addGap(14, 14, 14)
                                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(textAssignmentOR, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(textAssignmentXOR, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jToggleButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel33, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel32, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                                                .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel31, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(textBooleanANDLogical, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textBooleanXOREvaluation, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textBooleanOREvaluation, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textBooleanANDEvaluation, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textBooleanORLogical, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textBooleanNotEqual, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(textBooleanNegation, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(textBooleanEqual, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(textBitwiseAND, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8)
                                    .addComponent(textRelationalLess, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(textAssignmentMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textBitwiseOR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(textRelationalMore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel20)
                                    .addComponent(textAssignmentMultiply, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textBitwiseXOR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel26)
                                    .addComponent(textRelationalEqualLess, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textAssignmentPlus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(100, 100, 100)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textAssignmentDivide, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textAssignmentModulus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel36)
                                    .addComponent(jLabel27))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel35)
                                    .addComponent(textBooleanANDEvaluation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel34)
                                    .addComponent(textBooleanOREvaluation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(8, 8, 8)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textBooleanXOREvaluation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel33))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel25)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(textRelationalEqualMore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(textBooleanANDLogical, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel32)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textRelationalEqual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel24)
                                    .addComponent(jLabel31)
                                    .addComponent(textBooleanORLogical, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textRelationalNotEqual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel30)
                                    .addComponent(textBooleanNegation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textAssignmentAND, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel12))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29)
                            .addComponent(textBooleanEqual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)
                            .addComponent(textAssignmentOR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textBooleanNotEqual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28)
                            .addComponent(jLabel14)
                            .addComponent(textAssignmentXOR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(41, 64, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(calculate, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                    .addComponent(jToggleButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(9, 9, 9)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(labelX))
                            .addComponent(resetX))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(labelY)
                                .addComponent(resetY))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(labelResultX, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelResultY, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jMenu1.setText("File");

        itemClose.setText("Close");
        itemClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemCloseActionPerformed(evt);
            }
        });
        jMenu1.add(itemClose);

        jMenuBar1.add(jMenu1);

        jMenuAssignment.setText("Assignment");

        itemAssignSederhana.setText("= Sederhana");
        itemAssignSederhana.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignSederhanaActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignSederhana);

        itemAssignTambah.setText("+= Penambahan");
        itemAssignTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignTambahActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignTambah);

        itemAssignKurang.setText("-= Pengurangan");
        itemAssignKurang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignKurangActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignKurang);

        itemAssignBagi.setText("/= Pembagian");
        itemAssignBagi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignBagiActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignBagi);

        itemAssignModulus.setText("%= Modulus (sisa bagi)");
        itemAssignModulus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignModulusActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignModulus);

        itemAssignAND.setText("&= AND");
        itemAssignAND.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignANDActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignAND);

        itemAssignOR.setText("|= OR");
        itemAssignOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignORActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignOR);

        itemAssignXOR.setText("^= XOR");
        itemAssignXOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAssignXORActionPerformed(evt);
            }
        });
        jMenuAssignment.add(itemAssignXOR);

        jMenuBar1.add(jMenuAssignment);

        jMenuBitwise.setText("Bitwise");

        itemBitwiseAND.setText("& Bitwise AND");
        itemBitwiseAND.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBitwiseANDActionPerformed(evt);
            }
        });
        jMenuBitwise.add(itemBitwiseAND);

        itemBitwiseOR.setText("|| Bitwise OR");
        itemBitwiseOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBitwiseORActionPerformed(evt);
            }
        });
        jMenuBitwise.add(itemBitwiseOR);

        itemBitwiseXOR.setText("^ Bitwise XOR");
        itemBitwiseXOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBitwiseXORActionPerformed(evt);
            }
        });
        jMenuBitwise.add(itemBitwiseXOR);

        jMenuBar1.add(jMenuBitwise);

        jMenuRelational.setText("Relational");

        itemRelationalLess.setText("< Less than");
        itemRelationalLess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemRelationalLessActionPerformed(evt);
            }
        });
        jMenuRelational.add(itemRelationalLess);

        itemRelationalMore.setText("> More than");
        itemRelationalMore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemRelationalMoreActionPerformed(evt);
            }
        });
        jMenuRelational.add(itemRelationalMore);

        itemRelationalLessEqual.setText("<= Equal to less than");
        itemRelationalLessEqual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemRelationalLessEqualActionPerformed(evt);
            }
        });
        jMenuRelational.add(itemRelationalLessEqual);

        itemRelationalMoreEqual.setText(">= Equal to more than");
        itemRelationalMoreEqual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemRelationalMoreEqualActionPerformed(evt);
            }
        });
        jMenuRelational.add(itemRelationalMoreEqual);

        itemRelationalEqual.setText("== Equal to");
        itemRelationalEqual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemRelationalEqualActionPerformed(evt);
            }
        });
        jMenuRelational.add(itemRelationalEqual);

        itemRelationalNotEqual.setText("!= Not equal to");
        itemRelationalNotEqual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemRelationalNotEqualActionPerformed(evt);
            }
        });
        jMenuRelational.add(itemRelationalNotEqual);

        jMenuBar1.add(jMenuRelational);

        jMenuBoolean.setText("Boolean");

        itemBooleanANDeval.setText("& AND evaluation");
        itemBooleanANDeval.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanANDevalActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanANDeval);

        itemBooleanOREval.setText("| OR evaluation");
        itemBooleanOREval.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanOREvalActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanOREval);

        itemBooleanXOReval.setText("^ XOR evaluation");
        itemBooleanXOReval.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanXORevalActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanXOReval);

        itemBooleanANDlogic.setText("&& AND logical");
        itemBooleanANDlogic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanANDlogicActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanANDlogic);

        itemBooleanORlogic.setText("|| OR logical");
        itemBooleanORlogic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanORlogicActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanORlogic);

        itemBooleanNegation.setText("! Negation");
        itemBooleanNegation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanNegationActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanNegation);

        itemBooleanEqual.setText("== Equal to");
        itemBooleanEqual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanEqualActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanEqual);

        itemBooleanNotEqual.setText("!= Not equal to");
        itemBooleanNotEqual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBooleanNotEqualActionPerformed(evt);
            }
        });
        jMenuBoolean.add(itemBooleanNotEqual);

        jMenuBar1.add(jMenuBoolean);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void itemCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemCloseActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_itemCloseActionPerformed

    /**
     * ASSIGNMENT
     * @param evt 
     */
    private void itemAssignSederhanaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignSederhanaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemAssignSederhanaActionPerformed

    private void itemAssignTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignTambahActionPerformed
        
        x = Integer.parseInt(textX.getText());
        y = Integer.parseInt(textY.getText());
        result = x += y;
        textArea.setText(Integer.toString(result));
        
    }//GEN-LAST:event_itemAssignTambahActionPerformed

    private void itemAssignKurangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignKurangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemAssignKurangActionPerformed

    private void itemAssignBagiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignBagiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemAssignBagiActionPerformed

    private void itemAssignModulusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignModulusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemAssignModulusActionPerformed

    private void itemAssignANDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignANDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemAssignANDActionPerformed

    private void itemAssignORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignORActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemAssignORActionPerformed

    private void itemAssignXORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAssignXORActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemAssignXORActionPerformed

    /**
     * BITWISE
     * @param evt 
     */
    private void itemBitwiseANDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBitwiseANDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBitwiseANDActionPerformed

    private void itemBitwiseORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBitwiseORActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBitwiseORActionPerformed

    private void itemBitwiseXORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBitwiseXORActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBitwiseXORActionPerformed

    /**
     * RELATIONAL
     * @param evt 
     */
    private void itemRelationalLessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemRelationalLessActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemRelationalLessActionPerformed

    private void itemRelationalMoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemRelationalMoreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemRelationalMoreActionPerformed

    private void itemRelationalLessEqualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemRelationalLessEqualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemRelationalLessEqualActionPerformed

    private void itemRelationalMoreEqualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemRelationalMoreEqualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemRelationalMoreEqualActionPerformed

    private void itemRelationalEqualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemRelationalEqualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemRelationalEqualActionPerformed

    private void itemRelationalNotEqualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemRelationalNotEqualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemRelationalNotEqualActionPerformed

    /**
     * BOOLEAN
     * @param evt 
     */
    private void itemBooleanANDevalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanANDevalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanANDevalActionPerformed

    private void itemBooleanOREvalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanOREvalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanOREvalActionPerformed

    private void itemBooleanXORevalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanXORevalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanXORevalActionPerformed

    private void itemBooleanANDlogicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanANDlogicActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanANDlogicActionPerformed

    private void itemBooleanORlogicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanORlogicActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanORlogicActionPerformed

    private void itemBooleanNegationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanNegationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanNegationActionPerformed

    private void itemBooleanEqualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanEqualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanEqualActionPerformed

    private void itemBooleanNotEqualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBooleanNotEqualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemBooleanNotEqualActionPerformed

    private void resetYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetYActionPerformed

        textY.setText("");

    }//GEN-LAST:event_resetYActionPerformed

    private void resetXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetXActionPerformed

        textX.setText("");

    }//GEN-LAST:event_resetXActionPerformed

    private void calculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateActionPerformed
        
        if(textX.getText().equals("") || textY.getText().equals("")){
            
            JOptionPane.showMessageDialog(null, "Musnt empty both");
            
        } else{
            
            x = Integer.parseInt(textX.getText());
            y = Integer.parseInt(textY.getText());

            /**
             * ASSIGNMENT
             */
            int assignPlus  = x += y;
            int assignMin   = x -= y;
            int assignMult  = x *= y;
            int assignDiv   = x /= y;
            int assignModul = x %= y;
            int assignAND   = x &= y;
            int assignOR    = x |= y;
            int assignXOR   = x ^= y;
            
            textAssignmentPlus.setText(Integer.toString(assignPlus));
            textAssignmentMin.setText(Integer.toString(assignMin));
            textAssignmentMultiply.setText(Integer.toString(assignMult));
            textAssignmentDivide.setText(Integer.toString(assignDiv));
            textAssignmentModulus.setText(Integer.toString(assignModul));
            textAssignmentAND.setText(Integer.toString(assignAND));
            textAssignmentOR.setText(Integer.toString(assignOR));
            textAssignmentXOR.setText(Integer.toString(assignXOR));
            
            /**
             * BITWISE
             */
            int bitwiseAND = x & y;
            int bitwiseOR = x | y;  // cant be ||
            int bitwiseXOR = x ^ y;
            
            textBitwiseAND.setText(Integer.toString(bitwiseAND));
            textBitwiseOR.setText(Integer.toString(bitwiseOR));
            textBitwiseXOR.setText(Integer.toString(bitwiseXOR));
            
            /**
             * RELATIONAL
             * must be boolean
             */
            boolean relatLess = x < y;
            boolean relatMore = x > y;
            boolean relatEqualLess = x <= y;
            boolean relatEqualMore = x >= y;
            boolean relatEqual = x == y;
            boolean relatNotEqual = x != y;
            
            textRelationalLess.setText(Boolean.toString(relatLess));
            textRelationalMore.setText(Boolean.toString(relatMore));
            textRelationalEqualLess.setText(Boolean.toString(relatEqualLess));
            textRelationalEqualMore.setText(Boolean.toString(relatEqualMore));
            textRelationalEqual.setText(Boolean.toString(relatEqual));
            textRelationalNotEqual.setText(Boolean.toString(relatNotEqual));
            
            /**
             * BOOLEAN
             */
            
            
        }
        
    }//GEN-LAST:event_calculateActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new NewJFrame().setVisible(true);
            
//                new NewJFrame().setUndecorated(true);
//                new NewJFrame().getContentPane().setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
//                new NewJFrame().setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton calculate;
    private javax.swing.JMenuItem itemAssignAND;
    private javax.swing.JMenuItem itemAssignBagi;
    private javax.swing.JMenuItem itemAssignKurang;
    private javax.swing.JMenuItem itemAssignModulus;
    private javax.swing.JMenuItem itemAssignOR;
    private javax.swing.JMenuItem itemAssignSederhana;
    private javax.swing.JMenuItem itemAssignTambah;
    private javax.swing.JMenuItem itemAssignXOR;
    private javax.swing.JMenuItem itemBitwiseAND;
    private javax.swing.JMenuItem itemBitwiseOR;
    private javax.swing.JMenuItem itemBitwiseXOR;
    private javax.swing.JMenuItem itemBooleanANDeval;
    private javax.swing.JMenuItem itemBooleanANDlogic;
    private javax.swing.JMenuItem itemBooleanEqual;
    private javax.swing.JMenuItem itemBooleanNegation;
    private javax.swing.JMenuItem itemBooleanNotEqual;
    private javax.swing.JMenuItem itemBooleanOREval;
    private javax.swing.JMenuItem itemBooleanORlogic;
    private javax.swing.JMenuItem itemBooleanXOReval;
    private javax.swing.JMenuItem itemClose;
    private javax.swing.JMenuItem itemRelationalEqual;
    private javax.swing.JMenuItem itemRelationalLess;
    private javax.swing.JMenuItem itemRelationalLessEqual;
    private javax.swing.JMenuItem itemRelationalMore;
    private javax.swing.JMenuItem itemRelationalMoreEqual;
    private javax.swing.JMenuItem itemRelationalNotEqual;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenuAssignment;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuBitwise;
    private javax.swing.JMenu jMenuBoolean;
    private javax.swing.JMenu jMenuRelational;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JLabel labelResultX;
    private javax.swing.JLabel labelResultY;
    private javax.swing.JLabel labelX;
    private javax.swing.JLabel labelY;
    private javax.swing.JButton resetX;
    private javax.swing.JButton resetY;
    private javax.swing.JTextArea textArea;
    private javax.swing.JTextField textAssignmentAND;
    private javax.swing.JTextField textAssignmentDivide;
    private javax.swing.JTextField textAssignmentMin;
    private javax.swing.JTextField textAssignmentModulus;
    private javax.swing.JTextField textAssignmentMultiply;
    private javax.swing.JTextField textAssignmentOR;
    private javax.swing.JTextField textAssignmentPlus;
    private javax.swing.JTextField textAssignmentXOR;
    private javax.swing.JTextField textBitwiseAND;
    private javax.swing.JTextField textBitwiseOR;
    private javax.swing.JTextField textBitwiseXOR;
    private javax.swing.JTextField textBooleanANDEvaluation;
    private javax.swing.JTextField textBooleanANDLogical;
    private javax.swing.JTextField textBooleanEqual;
    private javax.swing.JTextField textBooleanNegation;
    private javax.swing.JTextField textBooleanNotEqual;
    private javax.swing.JTextField textBooleanOREvaluation;
    private javax.swing.JTextField textBooleanORLogical;
    private javax.swing.JTextField textBooleanXOREvaluation;
    private javax.swing.JTextField textRelationalEqual;
    private javax.swing.JTextField textRelationalEqualLess;
    private javax.swing.JTextField textRelationalEqualMore;
    private javax.swing.JTextField textRelationalLess;
    private javax.swing.JTextField textRelationalMore;
    private javax.swing.JTextField textRelationalNotEqual;
    private javax.swing.JTextField textX;
    private javax.swing.JTextField textY;
    // End of variables declaration//GEN-END:variables
}
